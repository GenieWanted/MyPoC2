//
//  LoginViewController2.h
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 24/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController2 : UIViewController

@end
