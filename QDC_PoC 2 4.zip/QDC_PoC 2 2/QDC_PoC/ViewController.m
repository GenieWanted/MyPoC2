//
//  ViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 13/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "ViewController.h"
#import "ProjectListingTableViewController.h"
#import "LoginViewController.h"
#import "BIZCircularTransitionAnimator.h"
#import "BIZCircularTransitionHandler.h"
#import "KVNProgress.h"
#import "SharedObj.h"
#import "UIViewController+ENPopUp.h"
#import "BIZPopupView/BIZPopupViewController.h"
#import "SCLAlertView.h"

@interface ViewController () {
    UIAlertController *loginAlertController;
}
@property (weak, nonatomic) IBOutlet UIView *clientView;
@property (weak, nonatomic) IBOutlet UIView *internalTeamView;
@property (nonatomic, strong) BIZCircularTransitionHandler *circularTransitionHandler;
@property (nonatomic, strong) UITextField *usernameTextfield;
@property (nonatomic, strong) UITextField *passwordTextfield;


@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    UIImageView *titleImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    titleImgView.contentMode = UIViewContentModeScaleAspectFit;
    [titleImgView setImage:[UIImage imageNamed:@"logo.png"]];
    self.navigationItem.titleView = titleImgView;
    
    UITapGestureRecognizer *clientTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clientButtonTapped:)];
    [self.clientView addGestureRecognizer:clientTapGesture];
    
    UITapGestureRecognizer *internalTeamTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(internalTeamTapped:)];
    [self.internalTeamView addGestureRecognizer:internalTeamTapGesture];

    self.circularTransitionHandler = [[BIZCircularTransitionHandler alloc] init];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)clientButtonTapped:(UITapGestureRecognizer *)gesture {
    //[self showSuccessSpinnerAfterDelay];
    [self showLoginAlertWith:@"Client - Login"];
    
}

-(void)internalTeamTapped:(UITapGestureRecognizer *)gesture {
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    ProjectListingTableViewController *destinationVC = [storyboard instantiateViewControllerWithIdentifier:@"ProNavVC"];
    
    
    [self.circularTransitionHandler transitionWithDestinationViewController:destinationVC initialTransitionPoint:self.self.view.center];
    [self presentViewController:destinationVC animated:YES completion:nil];


    //[self showLoginAlertWith:@"Internal Team - Login"];
   
}

-(void)showLoginAlertWith:(NSString *)title {
    
    loginAlertController = [UIAlertController alertControllerWithTitle:title message:@"Please enter your login credentials" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *loginAction = [UIAlertAction actionWithTitle:@"Login" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        if([loginAlertController.textFields[0].text isEqualToString:@""] || [loginAlertController.textFields[1].text isEqualToString:@""]) {
            [KVNProgress showErrorWithStatus:@"Username or password cannot be empty"];
        }
        else {
        [KVNProgress showWithStatus:@"Logging in.."];
        [self performSelector:@selector(showSuccessSpinnerAfterDelay) withObject:nil afterDelay:1.5];
        }
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {

    }];
    
    [loginAlertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Username";
    }];
    
    [loginAlertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Password";
        textField.secureTextEntry = YES;
    }];

    [loginAlertController addAction:cancelAction];
    [loginAlertController addAction:loginAction];
    [self presentViewController:loginAlertController animated:YES completion:nil];
    
}

-(void)showSuccessSpinnerAfterDelay {
    
    NSString *userName = loginAlertController.textFields[0].text;
    NSString *password = loginAlertController.textFields[1].text;
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    
   
    
   if(([userName isEqualToString:@"client"] && [password isEqualToString:@"client123"]) || ([userName isEqualToString:@"team"] && [password isEqualToString:@"team123"])) {
        
        // Success
            [KVNProgress showSuccessWithStatus:@"Login successfull!" completion:^{

                ProjectListingTableViewController *destinationVC = [storyboard instantiateViewControllerWithIdentifier:@"ProNavVC"];
        
        
                [self.circularTransitionHandler transitionWithDestinationViewController:destinationVC initialTransitionPoint:self.self.view.center];
                [self presentViewController:destinationVC animated:YES completion:nil];
            }];
    }
    else {
        // Failure
      
        [KVNProgress showErrorWithStatus:@"Invalid credentials. Please check the username or password"];
    }
}

-(void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if(motion == UIEventSubtypeMotionShake) {
        NSLog(@"Shaken Here");
        
        SCLAlertView *alertView = [[SCLAlertView alloc] init];

        self.usernameTextfield = [alertView addTextField:@"Username"];
        self.usernameTextfield.autocapitalizationType = UITextAutocapitalizationTypeNone;
        self.passwordTextfield = [alertView addTextField:@"Password"];
        self.passwordTextfield.secureTextEntry = YES;
        [alertView addButton:@"Login" actionBlock:^{
            if([self.usernameTextfield.text isEqualToString:@""] || [self.passwordTextfield.text isEqualToString:@""]) {
                
                [KVNProgress showErrorWithStatus:@"Username or password cannot be empty"];
            }
            else {
            [KVNProgress showWithStatus:@"Loading.."];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self performSelector:@selector(handleLogin:and:) withObject:self.usernameTextfield withObject:self.passwordTextfield];

            });
            }
            
        }];

        alertView.customViewColor = [UIColor colorWithRed:32.0/255.0 green:153.0/255.0 blue:210.0/255.0 alpha:1];
        alertView.showAnimationType = SlideInFromTop;
        alertView.hideAnimationType = SlideOutToBottom;

        [alertView showNotice:self title:@"Hello Notice" subTitle:@"This is a more descriptive notice text." closeButtonTitle:nil duration:0.0f]; // Notice

        [alertView showCustom:[UIImage imageNamed:@"client.png"] color:[UIColor redColor] title:@"Login" subTitle:@"Please enter your login credentials" closeButtonTitle:@"Cancel" duration:0.0f];

    }
}

-(void)handleLogin:(UITextField *)userNameTextField and:(UITextField *)passwordTextField {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    
    
    
    if(([userNameTextField.text isEqualToString:@"client"] && [passwordTextField.text isEqualToString:@"client123"]) || ([userNameTextField.text isEqualToString:@"team"] && [passwordTextField.text isEqualToString:@"team123"])) {
        
        // Success
        [KVNProgress showSuccessWithStatus:@"Login successfull!" completion:^{
            
            ProjectListingTableViewController *destinationVC = [storyboard instantiateViewControllerWithIdentifier:@"ProNavVC"];
            
            
            [self.circularTransitionHandler transitionWithDestinationViewController:destinationVC initialTransitionPoint:self.self.view.center];
            [self presentViewController:destinationVC animated:YES completion:nil];
        }];
    }
    else {
        // Failure
        
        [KVNProgress showErrorWithStatus:@"Invalid credentials. Please check the username or password"];
    }
}

@end
