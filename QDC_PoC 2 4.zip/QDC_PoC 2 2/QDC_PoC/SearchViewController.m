//
//  SearchViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 22/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "SearchViewController.h"
#import "fmdb/FMDatabase.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.searchTextField becomeFirstResponder];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)filterInfo:(NSString *)string {

        
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"UserDatabase" ofType:@"sqlite"]; // Accessing the pre-filled SQLiteDB here
        FMDatabase *database = [FMDatabase databaseWithPath:filePath];
        [database open];
    NSString *wildCardStr = [NSString stringWithFormat:@"%%%@%%", string];
    
    FMResultSet *results = [database executeQuery:[NSString stringWithFormat:@"SELECT * FROM ProjectListings WHERE projectName LIKE '%@'", wildCardStr]];
                                
        
        while ([results next]) {
            // NSLog(@"%@", results.resultDictionary);
        }
        [database close];
        

}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self dismissViewControllerAnimated:YES completion:nil];
    [self filterInfo:self.searchTextField.text];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"doneKeyReturned" object:self userInfo:[NSDictionary dictionaryWithObject:self.searchTextField.text forKey:@"searchText"]];
    
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)cancelBtnTapped:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
