//
//  LoginViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 22/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "LoginViewController.h"
#import "JJMaterialTextfield.h"
#import "KVNProgress.h"
#import "ProjectListingTableViewController.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet JJMaterialTextfield *userNameTextField;
@property (weak, nonatomic) IBOutlet JJMaterialTextfield *passwordTextField;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*self.userNameTextField.textColor = [UIColor whiteColor];
    self.passwordTextField.textColor = [UIColor whiteColor];
    self.userNameTextField.lineColor = [UIColor whiteColor];
    self.passwordTextField.lineColor = [UIColor whiteColor]; */
    
    
    self.userNameTextField.delegate = self;
    self.passwordTextField.delegate = self;
    self.userNameTextField.placeholderAttributes = @{NSFontAttributeName : [UIFont fontWithName:@"Helvetica-light" size:14],
                                                     NSForegroundColorAttributeName : [[UIColor blackColor] colorWithAlphaComponent:.8]};
    
    
    self.passwordTextField.placeholderAttributes = @{NSFontAttributeName : [UIFont fontWithName:@"Helvetica-light" size:14],
                                                     NSForegroundColorAttributeName : [[UIColor blackColor] colorWithAlphaComponent:.8]};
    
    // Do any additional setup after loading the view.
    
   // [self.userNameTextField becomeFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    if(textField == self.userNameTextField)
        [self.passwordTextField becomeFirstResponder];
    else {
        [textField resignFirstResponder];
        [self handleLogin:self.userNameTextField and:self.passwordTextField];
    }
    
    return YES;
}

-(void)handleLogin:(UITextField *)userName and:(UITextField *)password {
    if([userName.text isEqualToString:@""] || [password.text isEqualToString:@""]) {
        [KVNProgress showErrorWithStatus:@"All fields are required. Please check the fields if they are empty"];
    }
    if([userName.text isEqualToString:@"client"] && [password.text isEqualToString:@"client123"]) {
        [KVNProgress showWithStatus:@"Logging in.."];
        [self performSelector:@selector(handleSuccess) withObject:nil afterDelay:0.5];
    }
}

-(void)handleSuccess {
    [KVNProgress showSuccessWithStatus:@"Login Successfull!" completion:^{
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ProjectListingTableViewController *projectListingTableViewController = [storyboard instantiateViewControllerWithIdentifier:@"ProNavVC"];
        [self presentViewController:projectListingTableViewController animated:YES completion:nil];
    }];
}


@end
