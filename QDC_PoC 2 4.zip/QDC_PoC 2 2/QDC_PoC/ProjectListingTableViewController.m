//
//  ProjectListingTableViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 13/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "ProjectListingTableViewController.h"
#import "ProjectListingTableViewCell.h"
#import "ProjectDetails.h"
#import "FMDatabase.h"
#import "SharedObj.h"
#import "VCFloatingActionButton.h"
#import "ProjectListingViewController.h"
#import "KVNProgress.h"
#import "ViewController.h"


@interface ProjectListingTableViewController () {
    NSMutableArray *projectDetailsArray;
    UIView *floatView;

}

@property (nonatomic, strong) ProjectListingViewController *projectListingVC;
@end

@implementation ProjectListingTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    projectDetailsArray = [[NSMutableArray alloc] init];
    [self retrievedDatafromSQLiteWith:@""];

//    self.tableView.tableHeaderView = self.searchController.searchBar;
    
    self.searchController.delegate = self;
    [self performSelector:@selector(setFocusOnSearchbar) withObject:nil afterDelay:2.0];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(filterProjectListing:) name:@"doneKeyReturned" object:nil];
}

-(void)filterProjectListing:(NSNotification *)notification {
    [projectDetailsArray removeAllObjects];
    NSDictionary *theData = [notification userInfo];
    NSString *searchText = [theData valueForKey:@"searchText"];
    NSLog(@"Searched Text is %@", searchText);
    [KVNProgress showSuccessWithStatus:@"Filter Applied"];
    [self retrievedDatafromSQLiteWith:searchText];



}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [projectDetailsArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ProjectListingTableViewCell *cell = (ProjectListingTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"ProjectListingTableViewCell" forIndexPath:indexPath];
    if(cell == nil) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"ProjectListingTableViewCell" owner:self options:nil].lastObject;
    }
    cell.projectNameLabel.text = [[projectDetailsArray valueForKey:@"projectName"] objectAtIndex:indexPath.row];
    cell.projectStatusLabel.text = [[projectDetailsArray valueForKey:@"projectStatus"] objectAtIndex:indexPath.row];
    cell.clientNameLabel.text = [[projectDetailsArray valueForKey:@"clientName"] objectAtIndex:indexPath.row];
    cell.projectDateLabel.text = [NSString stringWithFormat:@"%@ to %@", [[projectDetailsArray valueForKey:@"startDate"] objectAtIndex:indexPath.row], [[projectDetailsArray valueForKey:@"endDate"] objectAtIndex:indexPath.row]];
    cell.projectUpdatedByLabel.text = [NSString stringWithFormat:@"Last updated by %@ on %@", [[projectDetailsArray valueForKey:@"lastUpdatedBy"] objectAtIndex:indexPath.row], [[projectDetailsArray valueForKey:@"lastUpdatedOn"] objectAtIndex:indexPath.row]];
    if([cell.projectStatusLabel.text isEqualToString:@"On Going"])
        cell.projectStatusLabel.backgroundColor = [UIColor orangeColor];
    else if ([cell.projectStatusLabel.text isEqualToString:@"Completed"])
        cell.projectStatusLabel.backgroundColor = [UIColor colorWithRed:44.0/255.0 green:191.0/255.0 blue:100.0/255.0 alpha:1.0];
    else if ([cell.projectStatusLabel.text isEqualToString:@"Pending"])
        cell.projectStatusLabel.backgroundColor = [UIColor redColor];
    return cell;
}

- (IBAction)doneButtonPressed:(id)sender {
    //[self dismissViewControllerAnimated:YES completion:nil];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController *dashboardViewController = [storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
    [self.navigationController popToViewController:dashboardViewController animated:YES];
}

- (void)retrievedDatafromSQLiteWith:(NSString *)string {
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"UserDatabase" ofType:@"sqlite"]; // Accessing the pre-filled SQLiteDB here
    FMDatabase *database = [FMDatabase databaseWithPath:filePath];
    [database open];
    NSString *wildCardStr = [NSString stringWithFormat:@"%%%@%%", string];
    
    FMResultSet *results = [database executeQuery:[NSString stringWithFormat:@"SELECT * FROM ProjectListings WHERE projectName LIKE '%@' ORDER BY projectStatus DESC", wildCardStr]];

    while ([results next]) {
        NSLog(@"Results: %@", results.resultDictionary);
        ProjectDetails *projectDetails = [[ProjectDetails alloc] init];
        projectDetails.projectName = [results.resultDictionary valueForKey:@"projectName"];
        projectDetails.clientName = [results.resultDictionary valueForKey:@"clientName"];
        projectDetails.startDate = [results.resultDictionary valueForKey:@"startDate"];
        projectDetails.endDate = [results.resultDictionary valueForKey:@"endDate"];
        projectDetails.lastUpdatedBy = [results.resultDictionary valueForKey:@"lastUpdatedBy"];
        projectDetails.lastUpdatedOn = [results.resultDictionary valueForKey:@"lastUpdatedOn"];
        projectDetails.projectStatus = [results.resultDictionary valueForKey:@"projectStatus"];
        [projectDetailsArray addObject:projectDetails];

    }
        [database close];
//    [self.tableView reloadData];
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationMiddle];
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    [UIView animateWithDuration:1.0 animations:^{
        
    }];
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if(projectDetailsArray.count == 0)
        return @"No matching projects found. Please edit your filter search";
    else
        return @"Current Projects";
}

-(NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
        return @"Please shake the device to refresh";

}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if(projectDetailsArray.count == 0)
        return 52;
    else
        return 32;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    ProjectListingTableViewCell *selectedCell = (ProjectListingTableViewCell *)[self.tableView cellForRowAtIndexPath:indexPath];
    SharedObj *sharedObj = [SharedObj sharedInstance];
    sharedObj.selectedProject = selectedCell.projectNameLabel.text;
}

- (void)willPresentSearchController:(UISearchController *)searchController {
    self.navigationController.navigationBar.translucent = YES;
}


-(void)setFocusOnSearchbar {
  //  [self.searchController.searchBar becomeFirstResponder];
}

-(void)floatingButtonTapped:(BOOL)status {
    if(status ==  YES) {
        NSLog(@"Got the signal");
    }
}

-(void)doSomething {
    NSLog(@"Hello");
}

-(void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if(motion == UIEventSubtypeMotionShake) {
        [projectDetailsArray removeAllObjects];
        [self retrievedDatafromSQLiteWith:@""];
        [KVNProgress showSuccessWithStatus:@"Refresh done!"];

    }
}

@end
