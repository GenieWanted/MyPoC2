//
//  LoginViewController.h
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 22/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "ViewController.h"

@interface LoginViewController : ViewController <UITextFieldDelegate>

@end
