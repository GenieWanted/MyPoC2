//
//  ProjectDetails.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 14/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "ProjectDetails.h"

@implementation ProjectDetails

@end
