//
//  ProjectListingTableViewCell.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 14/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "ProjectListingTableViewCell.h"

@implementation ProjectListingTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
