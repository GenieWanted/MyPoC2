//
//  OverallStatusTableViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 17/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "OverallStatusTableViewController.h"
#import "ProjectInfoTableViewCell.h"
#import "ProjectDetailsTableViewCell.h"
#import "ProInfoTableViewCell.h"
#import "PNPieChart.h"
#import "PNColor.h"

@interface OverallStatusTableViewController () {
    NSArray *items;
}
@property (weak, nonatomic) IBOutlet UITableViewCell *chartTableViewCell;

@end

@implementation OverallStatusTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self handleInputForTextField:self.statusField];
 items = @[
                       [PNPieChartDataItem dataItemWithValue:20 color:[UIColor purpleColor] description:@"Completed"],
                       [PNPieChartDataItem dataItemWithValue:80 color:PNGreen description:@"Remaining"],
                       ];
    
    
    

    [self.pnPieChart updateChartData:items];
    self.pnPieChart.descriptionTextColor = [UIColor whiteColor];
    self.pnPieChart.descriptionTextFont  = [UIFont fontWithName:@"Helvetica-Light" size:14.0];
    [self.pnPieChart strokeChart];
    self.pnPieChart.center = CGPointMake(self.chartTableViewCell.bounds.size.width /4, self.chartTableViewCell.bounds.size.height/2);
    

//    [self.chartTableViewCell.contentView addSubview:self.pnPieChart];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if(motion == UIEventSubtypeMotionShake) {
        [self updateTheChart];
    }
}

#pragma mark - Table view data source


-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 32;
}

#pragma mark - XYPieChart delegate methods

- (NSUInteger)numberOfSlicesInPieChart:(XYPieChart *)pieChart {
    return 2;
}

- (CGFloat)pieChart:(XYPieChart *)pieChart valueForSliceAtIndex:(NSUInteger)index {
    return 40.0f;
}

-(void)updateTheChart {
    int randomNo = arc4random() % 100;
    items = @[
              [PNPieChartDataItem dataItemWithValue:randomNo color:[UIColor orangeColor] description:@"Completed"],
              [PNPieChartDataItem dataItemWithValue:(100 - randomNo) color:PNGreen description:@"Remaining"],
              ];
    NSLog(@"Update the chart");
    [self.pnPieChart updateChartData:items];
    [self.pnPieChart strokeChart];
    
}

-(void)handleInputForTextField:(UITextField *)textField {
    UIPickerView *datePicker = [[UIPickerView alloc] init];
    
    textField.inputView = datePicker;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
