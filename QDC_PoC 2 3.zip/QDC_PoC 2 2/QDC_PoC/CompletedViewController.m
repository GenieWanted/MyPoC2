//
//  CompletedViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 21/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "CompletedViewController.h"
#import "ProInfoTableViewCell.h"
#import "ActivityTableViewCell.h"

@interface CompletedViewController ()

@end

@implementation CompletedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)cancelButtonTapped:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UITableView Delegate and Datasource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(section == 0)
        return 1;
    else
        return 5;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if(section == 0)
        return @"Project Info";
    else
        return @"Completed Activities";
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.section == 0) {
        ProInfoTableViewCell *proInfoCell = (ProInfoTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"ProInfoTableViewCell"];
        if(proInfoCell == nil) {
            proInfoCell = [[NSBundle mainBundle] loadNibNamed:@"ProInfoTableViewCell" owner:self options:0].lastObject;
        }
        return proInfoCell;
    }
    else {
        ActivityTableViewCell *activityCell = (ActivityTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"ActivityTableViewCell"];
        if(activityCell == nil) {
            activityCell = [[NSBundle mainBundle] loadNibNamed:@"activityCell" owner:self options:0].lastObject;
        }
        return activityCell;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 32;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section == 0)
        return 80;
    else
        return 70;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
