//
//  ProjectListingViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 21/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "ProjectListingViewController.h"
#import "UIView+draggable.h"
#import "UIViewController+ENPopUp.h"
#import "SearchViewController.h"
#import "BIZPopupViewController.h"

@interface ProjectListingViewController ()
@property (weak, nonatomic) IBOutlet UIView *searchFloatIcon;

@end

@implementation ProjectListingViewController
@synthesize delegate;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.searchFloatIcon enableDragging];

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)floatingBtnTapped:(id)sender {
//    NSLog(@"Button Tapped");
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"floatingButtonTapped" object:self
//                                                      userInfo:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:1] forKey:@"didTap"]];
//    
//
//
//    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    SearchViewController *searchViewController = [mainStoryboard instantiateViewControllerWithIdentifier:@"SearchViewController"];
    
   // BIZPopupViewController *bizPopupVC = [[BIZPopupViewController alloc] initWithContentViewController:searchViewController contentSize:CGSizeMake(self.view.frame.size.width, self.view.frame.size.height)];
    [self presentViewController:searchViewController animated:YES completion:nil];

    
}

-(void)didIt {
    if ([self.delegate respondsToSelector:@selector(doSomething)]) {
        NSLog(@"Inside the delegate");
        [self.delegate doSomething];
        
    }
}
- (IBAction)doneBtnTapped:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/




@end
