//
//  LoginViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 22/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "LoginViewController.h"
#import "JJMaterialTextfield.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet JJMaterialTextfield *userNameTextField;
@property (weak, nonatomic) IBOutlet JJMaterialTextfield *passwordTextField;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.userNameTextField.textColor = [UIColor whiteColor];
    self.passwordTextField.textColor = [UIColor whiteColor];
    self.userNameTextField.lineColor = [UIColor whiteColor];
    self.passwordTextField.lineColor = [UIColor whiteColor];
    
    self.userNameTextField.placeholderAttributes = @{NSFontAttributeName : [UIFont fontWithName:@"Helvetica-light" size:14],
                                                     NSForegroundColorAttributeName : [[UIColor whiteColor] colorWithAlphaComponent:.8]};
    
    
    self.passwordTextField.placeholderAttributes = @{NSFontAttributeName : [UIFont fontWithName:@"Helvetica-light" size:14],
                                                     NSForegroundColorAttributeName : [[UIColor whiteColor] colorWithAlphaComponent:.8]};
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

@end
