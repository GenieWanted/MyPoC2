//
//  ProjectListingTableViewController.h
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 13/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface ProjectListingTableViewController : UITableViewController <UISearchControllerDelegate> {

}

@property (nonatomic, strong) UISearchController *searchController;

@end
