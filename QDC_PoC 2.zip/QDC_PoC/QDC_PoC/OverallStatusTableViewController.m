//
//  OverallStatusTableViewController.m
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 17/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import "OverallStatusTableViewController.h"
#import "ProjectInfoTableViewCell.h"
#import "ProjectDetailsTableViewCell.h"
#import "ProInfoTableViewCell.h"
#import "PNPieChart.h"
#import "PNColor.h"

@interface OverallStatusTableViewController ()

@end

@implementation OverallStatusTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    NSArray *items = @[
                       [PNPieChartDataItem dataItemWithValue:20 color:PNGreen description:@"Completed"],
                       [PNPieChartDataItem dataItemWithValue:80 color:PNRed description:@"Remaining"],
                       ];
    
    
    

    self.pnPieChart = [[PNPieChart alloc] initWithFrame:self.pnPieChart.frame items:items];

    self.pnPieChart.descriptionTextColor = [UIColor whiteColor];
    self.pnPieChart.descriptionTextFont  = [UIFont fontWithName:@"Avenir-Medium" size:14.0];
    [self.pnPieChart strokeChart];
    [self.tableView addSubview:self.pnPieChart];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 32;
}

#pragma mark - XYPieChart delegate methods

- (NSUInteger)numberOfSlicesInPieChart:(XYPieChart *)pieChart {
    return 2;
}

- (CGFloat)pieChart:(XYPieChart *)pieChart valueForSliceAtIndex:(NSUInteger)index {
    return 40.0f;
}




/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
