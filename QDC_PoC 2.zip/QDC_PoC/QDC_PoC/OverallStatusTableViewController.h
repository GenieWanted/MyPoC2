//
//  OverallStatusTableViewController.h
//  QDC_PoC
//
//  Created by Verve Technology Services PTE Ltd. on 17/06/16.
//  Copyright © 2016 Verve Technology Services PTE Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XYPieChart.h"
#import "PNPieChart.h"

@interface OverallStatusTableViewController : UITableViewController <XYPieChartDataSource, XYPieChartDelegate>
@property (weak, nonatomic) IBOutlet XYPieChart *pieChart;
@property (strong, nonatomic) IBOutlet PNPieChart *pnPieChart;



@end
